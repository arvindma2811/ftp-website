// =========================
// AUTH.JS – SIMPLE FRONTEND AUTH
// =========================

// Save current user in localStorage
function loginUser(userData) {
    localStorage.setItem('user', JSON.stringify(userData));
    window.location.href = 'index.html'; // Redirect after login
}

// Register new user
function registerUser(userData) {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const exists = users.find(u => u.email === userData.email);
    if (exists) {
        alert("User already exists! Please log in.");
        window.location.href = 'login.html';
        return;
    }
    users.push(userData);
    localStorage.setItem('users', JSON.stringify(users));
    alert("Registration successful! Please log in.");
    window.location.href = 'login.html';
}

// Check login state
function checkAuth() {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user) {
        // If not logged in, redirect from protected pages
        const protectedPages = ['profile.html', 'analysis.html'];
        if (protectedPages.includes(location.pathname.split('/').pop())) {
            window.location.href = 'login.html';
        }
    } else {
        // If logged in, update navbar
        const profileLi = document.querySelector('.profile');
        if (profileLi) {
            profileLi.innerHTML = `
                <a href="#profile">
                    <img class="profile-pic" src="images/Pfp.jpeg" alt="Profile picture">
                    <span class="profile-text">${user.name}</span>
                </a>
                <ul class="dropdown-content">
                    <li><a href="profile.html">View Profile</a></li>
                    <li><a href="#" onclick="logout()">Logout</a></li>
                </ul>
            `;
        }
    }
}

// Logout
function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// Run checkAuth on page load
document.addEventListener('DOMContentLoaded', checkAuth);
